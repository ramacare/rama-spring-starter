package org.rama.mongo.mapper;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.processing.Generated;
import org.rama.entity.master.MasterItem;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-31T06:49:13+0000",
    comments = "version: 1.6.3, compiler: javac, environment: Java 17.0.18 (Eclipse Adoptium)"
)
@Component
public class MongoMasterItemMapperImpl extends MongoMasterItemMapper {

    @Override
    public org.rama.mongo.document.MasterItem newMongoEntity(MasterItem entity) {
        if ( entity == null ) {
            return null;
        }

        org.rama.mongo.document.MasterItem masterItem = new org.rama.mongo.document.MasterItem();

        masterItem.setId( entity.getId() );
        masterItem.setGroupKey( entity.getGroupKey() );
        masterItem.setItemCode( entity.getItemCode() );
        masterItem.setItemValue( entity.getItemValue() );
        masterItem.setItemValueAlternative( entity.getItemValueAlternative() );
        masterItem.setOrdering( entity.getOrdering() );
        masterItem.setKeyword( entity.getKeyword() );
        masterItem.setFilterText( entity.getFilterText() );
        masterItem.setMasterGroup( entity.getMasterGroup() );
        Map<String, Object> map = entity.getProperties();
        if ( map != null ) {
            masterItem.setProperties( new LinkedHashMap<String, Object>( map ) );
        }
        masterItem.setStatusCode( entity.getStatusCode() );
        masterItem.setUserstampField( entity.getUserstampField() );
        masterItem.setTimestampField( entity.getTimestampField() );

        return masterItem;
    }

    @Override
    public void updateMongoEntity(MasterItem entity, org.rama.mongo.document.MasterItem update) {
        if ( entity == null ) {
            return;
        }

        update.setId( entity.getId() );
        update.setGroupKey( entity.getGroupKey() );
        update.setItemCode( entity.getItemCode() );
        update.setItemValue( entity.getItemValue() );
        update.setItemValueAlternative( entity.getItemValueAlternative() );
        update.setOrdering( entity.getOrdering() );
        update.setKeyword( entity.getKeyword() );
        update.setFilterText( entity.getFilterText() );
        update.setMasterGroup( entity.getMasterGroup() );
        if ( update.getProperties() != null ) {
            Map<String, Object> map = entity.getProperties();
            if ( map != null ) {
                update.getProperties().clear();
                update.getProperties().putAll( map );
            }
            else {
                update.setProperties( null );
            }
        }
        else {
            Map<String, Object> map = entity.getProperties();
            if ( map != null ) {
                update.setProperties( new LinkedHashMap<String, Object>( map ) );
            }
        }
        update.setStatusCode( entity.getStatusCode() );
        update.setUserstampField( entity.getUserstampField() );
        update.setTimestampField( entity.getTimestampField() );
    }
}
