package org.rama.job;

import org.quartz.*;
import org.rama.service.system.SystemLogService;
import org.rama.service.system.SystemParameterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.Date;

@Component
/**
 * Base class for the platform's Quartz jobs.
 *
 * <h2>{@code @Transactional} on {@code executeInternal} does not work</h2>
 *
 * <p>Quartz calls {@link #execute(JobExecutionContext)}, which reaches
 * {@link #executeInternal(JobExecutionContext)} and in turn
 * {@link #executeInternal(JobDataMap)} through {@code this}. Both hops are
 * self-invocations, so they bypass the Spring proxy and a subclass's
 * {@code @Transactional} never applies — whether or not the instance is proxied
 * ({@code SpringBeanJobFactory} builds jobs via
 * {@code AutowireCapableBeanFactory.createBean}, so one may well exist).
 *
 * <p>A subclass needing a transaction must obtain it somewhere a proxy is actually
 * crossed: delegate to a {@code @Transactional} service bean, or annotate the repository
 * method. Putting {@code @Transactional} on {@code executeInternal} produces a job that
 * appears transactional, passes any test that calls the bean directly — such a call
 * <em>does</em> go through the proxy — and silently runs without a transaction the moment
 * Quartz fires it. See starter#47.
 */
public abstract class SmartJob implements Job {
    @Autowired
    protected SystemLogService systemLogService;
    @Autowired
    protected SystemParameterService systemParameterService;

    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        // Quartz worker threads carry no authenticated SecurityContext, so the global
        // Auditable userstamp listener would stamp createdBy/updatedBy as null/fallback.
        // Establish a synthetic principal (the job name) for the duration of the run so
        // entities written by the job are attributable to it. Cleared in finally —
        // Quartz threads are pooled and a leaked context would bleed into the next job.
        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(new UsernamePasswordAuthenticationToken(
                resolveJobPrincipal(jobExecutionContext), "N/A", Collections.emptyList()));
        SecurityContextHolder.setContext(context);
        try {
            JobDetail jobDetail = executeInternal(jobExecutionContext);
            JobDataMap dataMap = jobDetail.getJobDataMap();

            if (dataMap.getBoolean("runNext")) {
                Long runNextSeconds = dataMap.containsKey("runNextSeconds") ? Long.parseLong(dataMap.get("runNextSeconds").toString()) : null;
                dataMap.remove("runNext");
                dataMap.remove("runNextSeconds");
                reschedule(jobExecutionContext, jobDetail, dataMap, runNextSeconds);
            } else {
                try {
                    jobExecutionContext.getScheduler().addJob(jobDetail, true);
                    removeNextRun(jobExecutionContext);
                } catch (SchedulerException e) {
                    throw new RuntimeException("Failed to persist job result", e);
                }
            }
        } finally {
            SecurityContextHolder.clearContext();
        }
    }

    /**
     * Principal stamped onto entities written during this job's execution. Defaults to
     * the job's key name (so audit/revision rows attribute writes to the specific job),
     * falling back to {@code "quartz"} when the name is absent. Override to customise.
     */
    protected String resolveJobPrincipal(JobExecutionContext jobExecutionContext) {
        String name = jobExecutionContext.getJobDetail().getKey().getName();
        return (name == null || name.isBlank()) ? "quartz" : name;
    }

    public JobDetail executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        JobDetail jobDetail = jobExecutionContext.getJobDetail();
        JobDataMap jobDataMap = jobDetail.getJobDataMap();

        executeInternal(jobDataMap);

        jobDataMap.put("lastExecutedDatetime", OffsetDateTime.now().toString());

        return jobDetail;
    }

    public abstract void executeInternal(JobDataMap jobDataMap);

    protected void reschedule(JobExecutionContext jobExecutionContext, JobDetail jobDetail, JobDataMap dataMap, Long runNextSeconds) {
        try {
            Scheduler scheduler = jobExecutionContext.getScheduler();
            JobKey jobKey = jobDetail.getKey();
            JobDetail updatedJob = JobBuilder.newJob(jobDetail.getJobClass())
                    .withIdentity(jobKey)
                    .usingJobData(new JobDataMap(dataMap))
                    .storeDurably()
                    .build();

            String nextRunTriggerKey = (jobExecutionContext.getTrigger().getKey().getName().endsWith("_nextRun")) ? jobExecutionContext.getTrigger().getKey().getName() : jobExecutionContext.getTrigger().getKey().getName() + "_nextRun";
            TriggerKey triggerKey = TriggerKey.triggerKey(nextRunTriggerKey, jobKey.getGroup());
            scheduler.unscheduleJob(triggerKey);

            TriggerBuilder<Trigger> triggerBuilder = TriggerBuilder.newTrigger()
                    .withIdentity(triggerKey)
                    .forJob(updatedJob);

            Trigger trigger = (runNextSeconds == null)
                    ? triggerBuilder.startNow().build()
                    : triggerBuilder.startAt(Date.from(Instant.now().plusSeconds((runNextSeconds>3L) ? runNextSeconds : 3L))).build();

            scheduler.addJob(updatedJob, true);
            scheduler.scheduleJob(trigger);
        } catch (SchedulerException e) {
            throw new RuntimeException("Failed to reschedule job with updated state", e);
        }
    }

    protected void removeNextRun(JobExecutionContext jobExecutionContext) {
        try {
            Scheduler scheduler = jobExecutionContext.getScheduler();
            JobKey jobKey = jobExecutionContext.getJobDetail().getKey();
            TriggerKey nextRunTriggerKey = TriggerKey.triggerKey((jobExecutionContext.getTrigger().getKey().getName().endsWith("_nextRun")) ? jobExecutionContext.getTrigger().getKey().getName() : jobExecutionContext.getTrigger().getKey().getName() + "_nextRun", jobKey.getGroup());

            if (scheduler.checkExists(nextRunTriggerKey)) scheduler.unscheduleJob(nextRunTriggerKey);
        } catch (SchedulerException e) {
            throw new RuntimeException("Failed to remove next run job and trigger", e);
        }
    }

    @FunctionalInterface
    public interface ChunkJobRunner {
        long run(JobDataMap jobDataMap,long offset, String offsetParameter,long chunkSize,long maximum);
    }

    protected <T> void chunkJob(JobDataMap jobDataMap, ChunkJobRunner chunkJobRunner, Long runNextSeconds) {
        long offset = jobDataMap.containsKey("offset") ? getLongIntSafe(jobDataMap, "offset") : 0;
        long maximum = jobDataMap.containsKey("maximum") ? getLongIntSafe(jobDataMap, "maximum") : 0;

        String offsetParameter = (jobDataMap.containsKey("offsetParameter")) ? jobDataMap.getString("offsetParameter") : null;

        long chunkSize = (jobDataMap.containsKey("chunkSize")) ? getLongIntSafe(jobDataMap, "chunkSize") : 100L;

        if (offsetParameter != null) {
            String offsetParameterValue = systemParameterService.getParameter(offsetParameter);
            offsetParameterValue = offsetParameterValue == null ? "0" : offsetParameterValue;
            offset = Long.parseLong(offsetParameterValue);
        }

        if (maximum > 0) {
            chunkSize = Math.max(0, Math.min(chunkSize, maximum - offset));
        }

        long successCount = chunkJobRunner.run(jobDataMap,offset,offsetParameter,chunkSize,maximum);

        if (successCount > 0 && (maximum == 0 || offset + chunkSize < maximum)) {
            jobDataMap.put("offset", offset + chunkSize);
            jobDataMap.put("runNext", true);
            if (runNextSeconds != null && runNextSeconds > 0) {
                jobDataMap.put("runNextSeconds", runNextSeconds);
            }
            jobDataMap.put("status", "running");
        } else {
            if (maximum > 0 && offset + chunkSize > maximum) {
                jobDataMap.put("offset", maximum);
            }
            jobDataMap.put("status", "completed");
        }
    }

    protected long getLongIntSafe(JobDataMap jobDataMap, String key) {
        try {
            return jobDataMap.getLong(key);
        } catch (ClassCastException e) {
            return Long.parseLong(jobDataMap.get(key).toString());
        }
    }
}
