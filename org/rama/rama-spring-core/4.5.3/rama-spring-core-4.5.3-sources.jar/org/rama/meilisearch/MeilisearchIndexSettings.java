package org.rama.meilisearch;

import lombok.Builder;
import lombok.Getter;

import java.util.LinkedHashMap;
import java.util.Map;

import static java.util.Collections.emptyMap;

/**
 * A plain, code-buildable equivalent of {@link org.rama.annotation.SyncToMeilisearch}'s settings
 * attributes -- {@code null}/empty means "leave this setting untouched", the same convention the
 * annotation uses, so applying one built here behaves identically to applying the annotation
 * directly (see {@link MeilisearchIndexInitializer}, which both share).
 *
 * <p>Exists for {@link MeilisearchIndexSettingsResolver}: an annotation's compile-time constants
 * can't express "different settings per split index" (see
 * {@link org.rama.annotation.SyncToMeilisearch#indexNameField()}) without deeply nested,
 * duplicated annotation types for every setting -- a plain object supports the ordinary Java code
 * a resolver needs (loops, conditionals, externalized config).
 */
@Getter
@Builder
public class MeilisearchIndexSettings {
    @Builder.Default
    private String[] searchableAttributes = new String[0];
    @Builder.Default
    private String[] filterableAttributes = new String[0];
    @Builder.Default
    private String[] sortableAttributes = new String[0];
    @Builder.Default
    private String[] rankingRules = new String[0];
    /** {@code null} leaves Meilisearch's typo tolerance enablement untouched. */
    private Boolean typoToleranceEnabled;
    /** {@code null} leaves Meilisearch's own threshold (4) untouched. */
    private Integer typoToleranceMinWordSizeOneTypo;
    /** {@code null} leaves Meilisearch's own threshold (9) untouched. */
    private Integer typoToleranceMinWordSizeTwoTypos;
    @Builder.Default
    private Map<String, String[]> synonyms = emptyMap();

    /** The settings a plain (unsplit, or split-with-no-matching-resolver) entity already gets
     * today, straight off its {@code @SyncToMeilisearch}. */
    public static MeilisearchIndexSettings fromAnnotation(org.rama.annotation.SyncToMeilisearch annotation) {
        MeilisearchIndexSettingsBuilder builder = MeilisearchIndexSettings.builder()
                .searchableAttributes(annotation.searchableAttributes())
                .filterableAttributes(annotation.filterableAttributes())
                .sortableAttributes(annotation.sortableAttributes())
                .rankingRules(annotation.rankingRules());
        if (!annotation.typoToleranceEnabled()
                || annotation.typoToleranceMinWordSizeOneTypo() >= 0
                || annotation.typoToleranceMinWordSizeTwoTypos() >= 0) {
            builder.typoToleranceEnabled(annotation.typoToleranceEnabled());
            if (annotation.typoToleranceMinWordSizeOneTypo() >= 0) {
                builder.typoToleranceMinWordSizeOneTypo(annotation.typoToleranceMinWordSizeOneTypo());
            }
            if (annotation.typoToleranceMinWordSizeTwoTypos() >= 0) {
                builder.typoToleranceMinWordSizeTwoTypos(annotation.typoToleranceMinWordSizeTwoTypos());
            }
        }
        if (annotation.synonyms().length > 0) {
            Map<String, String[]> synonyms = new java.util.LinkedHashMap<>();
            for (org.rama.annotation.SyncToMeilisearch.Synonym synonym : annotation.synonyms()) {
                synonyms.put(synonym.word(), synonym.mappings());
            }
            builder.synonyms(synonyms);
        }
        return builder.build();
    }

    /**
     * {@code this} layered on top of {@code base}, field by field: a field {@code this} leaves at
     * its "untouched" default (empty array/map, or {@code null}) falls through to {@code base}'s
     * value for that same field instead of clearing it.
     *
     * <p>Without this, a {@link MeilisearchIndexSettingsResolver} that overrides one setting (say
     * {@code synonyms}) for one split value would silently drop every <em>other</em> setting the
     * entity's own {@code @SyncToMeilisearch} declares for that index (e.g.
     * {@code filterableAttributes}, needed for every search filter to keep working) -- a resolver
     * would have to remember to repeat the whole annotation in every branch it writes. Call this
     * as {@code resolverResult.layeredOver(MeilisearchIndexSettings.fromAnnotation(annotation))}.
     */
    public MeilisearchIndexSettings layeredOver(MeilisearchIndexSettings base) {
        return MeilisearchIndexSettings.builder()
                .searchableAttributes(searchableAttributes.length > 0 ? searchableAttributes : base.searchableAttributes)
                .filterableAttributes(filterableAttributes.length > 0 ? filterableAttributes : base.filterableAttributes)
                .sortableAttributes(sortableAttributes.length > 0 ? sortableAttributes : base.sortableAttributes)
                .rankingRules(rankingRules.length > 0 ? rankingRules : base.rankingRules)
                .typoToleranceEnabled(typoToleranceEnabled != null ? typoToleranceEnabled : base.typoToleranceEnabled)
                .typoToleranceMinWordSizeOneTypo(typoToleranceMinWordSizeOneTypo != null ? typoToleranceMinWordSizeOneTypo : base.typoToleranceMinWordSizeOneTypo)
                .typoToleranceMinWordSizeTwoTypos(typoToleranceMinWordSizeTwoTypos != null ? typoToleranceMinWordSizeTwoTypos : base.typoToleranceMinWordSizeTwoTypos)
                .synonyms(!synonyms.isEmpty() ? synonyms : base.synonyms)
                .build();
    }

    /**
     * Like {@link #layeredOver}, except synonyms merge per-word instead of one map replacing the
     * other outright: a word {@code this} declares overrides {@code base}'s mapping for that same
     * word (or adds a new one), but a word only {@code base} declares still applies. Every other
     * field behaves exactly as {@link #layeredOver}.
     *
     * <p>For an admin-configurable override layer (see {@code MeilisearchIndexSettingOverrideService}
     * in ramaservice): an admin adding one word to the dictionary must not silently discard every
     * word the code already shipped, which whole-map replacement would do.
     */
    public MeilisearchIndexSettings mergedOnto(MeilisearchIndexSettings base) {
        MeilisearchIndexSettings layered = layeredOver(base);
        if (synonyms.isEmpty()) {
            return layered;
        }
        Map<String, String[]> merged = new LinkedHashMap<>(base.synonyms);
        merged.putAll(synonyms);
        return MeilisearchIndexSettings.builder()
                .searchableAttributes(layered.searchableAttributes)
                .filterableAttributes(layered.filterableAttributes)
                .sortableAttributes(layered.sortableAttributes)
                .rankingRules(layered.rankingRules)
                .typoToleranceEnabled(layered.typoToleranceEnabled)
                .typoToleranceMinWordSizeOneTypo(layered.typoToleranceMinWordSizeOneTypo)
                .typoToleranceMinWordSizeTwoTypos(layered.typoToleranceMinWordSizeTwoTypos)
                .synonyms(merged)
                .build();
    }
}
