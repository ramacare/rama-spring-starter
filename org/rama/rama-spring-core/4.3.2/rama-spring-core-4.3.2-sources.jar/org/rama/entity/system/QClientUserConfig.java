package org.rama.entity.system;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QClientUserConfig is a Querydsl query type for ClientUserConfig
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QClientUserConfig extends EntityPathBase<ClientUserConfig> {

    private static final long serialVersionUID = 2072073037L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QClientUserConfig clientUserConfig = new QClientUserConfig("clientUserConfig");

    public final StringPath clientUsername = createString("clientUsername");

    public final MapPath<String, Object, SimplePath<Object>> configuration = this.<String, Object, SimplePath<Object>>createMap("configuration", String.class, Object.class, SimplePath.class);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final DateTimePath<java.time.OffsetDateTime> lastSeenDatetime = createDateTime("lastSeenDatetime", java.time.OffsetDateTime.class);

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QClientUserConfig(String variable) {
        this(ClientUserConfig.class, forVariable(variable), INITS);
    }

    public QClientUserConfig(Path<? extends ClientUserConfig> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QClientUserConfig(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QClientUserConfig(PathMetadata metadata, PathInits inits) {
        this(ClientUserConfig.class, metadata, inits);
    }

    public QClientUserConfig(Class<? extends ClientUserConfig> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

