package org.rama.entity.system;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;


/**
 * QSystemRequestDedup is a Querydsl query type for SystemRequestDedup
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QSystemRequestDedup extends EntityPathBase<SystemRequestDedup> {

    private static final long serialVersionUID = 1005168979L;

    public static final QSystemRequestDedup systemRequestDedup = new QSystemRequestDedup("systemRequestDedup");

    public final DateTimePath<java.time.OffsetDateTime> createdAt = createDateTime("createdAt", java.time.OffsetDateTime.class);

    public final DateTimePath<java.time.OffsetDateTime> expiresAt = createDateTime("expiresAt", java.time.OffsetDateTime.class);

    public final StringPath id = createString("id");

    public final StringPath method = createString("method");

    public final StringPath responseJson = createString("responseJson");

    public final EnumPath<SystemRequestDedup.Status> status = createEnum("status", SystemRequestDedup.Status.class);

    public final StringPath username = createString("username");

    public QSystemRequestDedup(String variable) {
        super(SystemRequestDedup.class, forVariable(variable));
    }

    public QSystemRequestDedup(Path<? extends SystemRequestDedup> path) {
        super(path.getType(), path.getMetadata());
    }

    public QSystemRequestDedup(PathMetadata metadata) {
        super(SystemRequestDedup.class, metadata);
    }

}

