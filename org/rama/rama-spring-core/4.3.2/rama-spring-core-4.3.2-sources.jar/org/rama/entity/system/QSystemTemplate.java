package org.rama.entity.system;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QSystemTemplate is a Querydsl query type for SystemTemplate
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QSystemTemplate extends EntityPathBase<SystemTemplate> {

    private static final long serialVersionUID = -1212777666L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QSystemTemplate systemTemplate = new QSystemTemplate("systemTemplate");

    public final StringPath id = createString("id");

    public final EnumPath<org.rama.entity.StatusCode> statusCode = createEnum("statusCode", org.rama.entity.StatusCode.class);

    public final StringPath template = createString("template");

    public final StringPath templateCode = createString("templateCode");

    public final StringPath templateName = createString("templateName");

    public final StringPath templateScript = createString("templateScript");

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QSystemTemplate(String variable) {
        this(SystemTemplate.class, forVariable(variable), INITS);
    }

    public QSystemTemplate(Path<? extends SystemTemplate> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QSystemTemplate(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QSystemTemplate(PathMetadata metadata, PathInits inits) {
        this(SystemTemplate.class, metadata, inits);
    }

    public QSystemTemplate(Class<? extends SystemTemplate> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

