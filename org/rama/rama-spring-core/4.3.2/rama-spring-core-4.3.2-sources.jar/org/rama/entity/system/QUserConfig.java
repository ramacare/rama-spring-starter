package org.rama.entity.system;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QUserConfig is a Querydsl query type for UserConfig
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QUserConfig extends EntityPathBase<UserConfig> {

    private static final long serialVersionUID = -1791061790L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QUserConfig userConfig = new QUserConfig("userConfig");

    public final MapPath<String, Object, SimplePath<Object>> configuration = this.<String, Object, SimplePath<Object>>createMap("configuration", String.class, Object.class, SimplePath.class);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final DateTimePath<java.time.OffsetDateTime> lastSeenDatetime = createDateTime("lastSeenDatetime", java.time.OffsetDateTime.class);

    public final org.rama.entity.QTimestampField timestampField;

    public final StringPath username = createString("username");

    public final org.rama.entity.QUserstampField userstampField;

    public QUserConfig(String variable) {
        this(UserConfig.class, forVariable(variable), INITS);
    }

    public QUserConfig(Path<? extends UserConfig> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QUserConfig(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QUserConfig(PathMetadata metadata, PathInits inits) {
        this(UserConfig.class, metadata, inits);
    }

    public QUserConfig(Class<? extends UserConfig> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

