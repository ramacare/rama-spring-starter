package org.rama.entity.security;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QApiKey is a Querydsl query type for ApiKey
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QApiKey extends EntityPathBase<ApiKey> {

    private static final long serialVersionUID = 391264937L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QApiKey apiKey = new QApiKey("apiKey");

    public final BooleanPath enabled = createBoolean("enabled");

    public final DateTimePath<java.time.OffsetDateTime> expiresAt = createDateTime("expiresAt", java.time.OffsetDateTime.class);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final StringPath keyHash = createString("keyHash");

    public final DateTimePath<java.time.OffsetDateTime> lastUsedAt = createDateTime("lastUsedAt", java.time.OffsetDateTime.class);

    public final StringPath name = createString("name");

    public final ListPath<String, StringPath> roles = this.<String, StringPath>createList("roles", String.class, StringPath.class, PathInits.DIRECT2);

    public final org.rama.entity.QTimestampField timestampField;

    public final StringPath username = createString("username");

    public final org.rama.entity.QUserstampField userstampField;

    public QApiKey(String variable) {
        this(ApiKey.class, forVariable(variable), INITS);
    }

    public QApiKey(Path<? extends ApiKey> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QApiKey(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QApiKey(PathMetadata metadata, PathInits inits) {
        this(ApiKey.class, metadata, inits);
    }

    public QApiKey(Class<? extends ApiKey> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

