package org.rama.entity.master;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QMasterGroup is a Querydsl query type for MasterGroup
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QMasterGroup extends EntityPathBase<MasterGroup> {

    private static final long serialVersionUID = -1332883045L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QMasterGroup masterGroup = new QMasterGroup("masterGroup");

    public final MapPath<String, Object, SimplePath<Object>> defaultProperties = this.<String, Object, SimplePath<Object>>createMap("defaultProperties", String.class, Object.class, SimplePath.class);

    public final StringPath description = createString("description");

    public final StringPath groupKey = createString("groupKey");

    public final StringPath groupName = createString("groupName");

    public final ListPath<MasterItem, QMasterItem> masterItems = this.<MasterItem, QMasterItem>createList("masterItems", MasterItem.class, QMasterItem.class, PathInits.DIRECT2);

    public final StringPath propertiesTemplate = createString("propertiesTemplate");

    public final EnumPath<org.rama.entity.StatusCode> statusCode = createEnum("statusCode", org.rama.entity.StatusCode.class);

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QMasterGroup(String variable) {
        this(MasterGroup.class, forVariable(variable), INITS);
    }

    public QMasterGroup(Path<? extends MasterGroup> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QMasterGroup(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QMasterGroup(PathMetadata metadata, PathInits inits) {
        this(MasterGroup.class, metadata, inits);
    }

    public QMasterGroup(Class<? extends MasterGroup> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

