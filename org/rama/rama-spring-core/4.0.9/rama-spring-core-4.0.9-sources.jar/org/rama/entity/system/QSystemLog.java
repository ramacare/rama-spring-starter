package org.rama.entity.system;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QSystemLog is a Querydsl query type for SystemLog
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QSystemLog extends EntityPathBase<SystemLog> {

    private static final long serialVersionUID = -212022784L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QSystemLog systemLog = new QSystemLog("systemLog");

    public final MapPath<String, Object, SimplePath<Object>> detail = this.<String, Object, SimplePath<Object>>createMap("detail", String.class, Object.class, SimplePath.class);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final StringPath logKey = createString("logKey");

    public final EnumPath<SystemLog.LogLevel> logLevel = createEnum("logLevel", SystemLog.LogLevel.class);

    public final StringPath message = createString("message");

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QSystemLog(String variable) {
        this(SystemLog.class, forVariable(variable), INITS);
    }

    public QSystemLog(Path<? extends SystemLog> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QSystemLog(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QSystemLog(PathMetadata metadata, PathInits inits) {
        this(SystemLog.class, metadata, inits);
    }

    public QSystemLog(Class<? extends SystemLog> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

