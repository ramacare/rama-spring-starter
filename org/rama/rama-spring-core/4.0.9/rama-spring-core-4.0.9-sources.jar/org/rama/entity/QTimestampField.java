package org.rama.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;


/**
 * QTimestampField is a Querydsl query type for TimestampField
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEmbeddableSerializer")
public class QTimestampField extends BeanPath<TimestampField> {

    private static final long serialVersionUID = -2015893330L;

    public static final QTimestampField timestampField = new QTimestampField("timestampField");

    public final DateTimePath<java.time.OffsetDateTime> createdAt = createDateTime("createdAt", java.time.OffsetDateTime.class);

    public final DateTimePath<java.time.OffsetDateTime> updatedAt = createDateTime("updatedAt", java.time.OffsetDateTime.class);

    public QTimestampField(String variable) {
        super(TimestampField.class, forVariable(variable));
    }

    public QTimestampField(Path<? extends TimestampField> path) {
        super(path.getType(), path.getMetadata());
    }

    public QTimestampField(PathMetadata metadata) {
        super(TimestampField.class, metadata);
    }

}

