package org.rama.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;


/**
 * QUserstampField is a Querydsl query type for UserstampField
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEmbeddableSerializer")
public class QUserstampField extends BeanPath<UserstampField> {

    private static final long serialVersionUID = 216259628L;

    public static final QUserstampField userstampField = new QUserstampField("userstampField");

    public final StringPath createdBy = createString("createdBy");

    public final StringPath updatedBy = createString("updatedBy");

    public QUserstampField(String variable) {
        super(UserstampField.class, forVariable(variable));
    }

    public QUserstampField(Path<? extends UserstampField> path) {
        super(path.getType(), path.getMetadata());
    }

    public QUserstampField(PathMetadata metadata) {
        super(UserstampField.class, metadata);
    }

}

