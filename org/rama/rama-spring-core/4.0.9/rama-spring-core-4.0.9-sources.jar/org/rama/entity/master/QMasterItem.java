package org.rama.entity.master;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QMasterItem is a Querydsl query type for MasterItem
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QMasterItem extends EntityPathBase<MasterItem> {

    private static final long serialVersionUID = -181482377L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QMasterItem masterItem = new QMasterItem("masterItem");

    public final StringPath filterText = createString("filterText");

    public final StringPath groupKey = createString("groupKey");

    public final StringPath id = createString("id");

    public final StringPath itemCode = createString("itemCode");

    public final StringPath itemValue = createString("itemValue");

    public final StringPath itemValueAlternative = createString("itemValueAlternative");

    public final StringPath keyword = createString("keyword");

    public final QMasterGroup masterGroup;

    public final NumberPath<Integer> ordering = createNumber("ordering", Integer.class);

    public final MapPath<String, Object, SimplePath<Object>> properties = this.<String, Object, SimplePath<Object>>createMap("properties", String.class, Object.class, SimplePath.class);

    public final EnumPath<org.rama.entity.StatusCode> statusCode = createEnum("statusCode", org.rama.entity.StatusCode.class);

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QMasterItem(String variable) {
        this(MasterItem.class, forVariable(variable), INITS);
    }

    public QMasterItem(Path<? extends MasterItem> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QMasterItem(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QMasterItem(PathMetadata metadata, PathInits inits) {
        this(MasterItem.class, metadata, inits);
    }

    public QMasterItem(Class<? extends MasterItem> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.masterGroup = inits.isInitialized("masterGroup") ? new QMasterGroup(forProperty("masterGroup"), inits.get("masterGroup")) : null;
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

