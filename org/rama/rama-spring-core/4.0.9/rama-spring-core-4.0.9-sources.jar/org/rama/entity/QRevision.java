package org.rama.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QRevision is a Querydsl query type for Revision
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QRevision extends EntityPathBase<Revision> {

    private static final long serialVersionUID = -748027259L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QRevision revision = new QRevision("revision");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final StringPath mrn = createString("mrn");

    public final MapPath<String, Object, SimplePath<Object>> revisionChange = this.<String, Object, SimplePath<Object>>createMap("revisionChange", String.class, Object.class, SimplePath.class);

    public final MapPath<String, Object, SimplePath<Object>> revisionData = this.<String, Object, SimplePath<Object>>createMap("revisionData", String.class, Object.class, SimplePath.class);

    public final DateTimePath<java.time.OffsetDateTime> revisionDatetime = createDateTime("revisionDatetime", java.time.OffsetDateTime.class);

    public final StringPath revisionEntity = createString("revisionEntity");

    public final StringPath revisionKey = createString("revisionKey");

    public final QTimestampField timestampField;

    public final QUserstampField userstampField;

    public QRevision(String variable) {
        this(Revision.class, forVariable(variable), INITS);
    }

    public QRevision(Path<? extends Revision> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QRevision(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QRevision(PathMetadata metadata, PathInits inits) {
        this(Revision.class, metadata, inits);
    }

    public QRevision(Class<? extends Revision> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new QUserstampField(forProperty("userstampField")) : null;
    }

}

