package org.rama.entity.asset;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QAssetFile is a Querydsl query type for AssetFile
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QAssetFile extends EntityPathBase<AssetFile> {

    private static final long serialVersionUID = -256616156L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QAssetFile assetFile = new QAssetFile("assetFile");

    public final StringPath bucketName = createString("bucketName");

    public final StringPath fileName = createString("fileName");

    public final StringPath fileType = createString("fileType");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final StringPath location = createString("location");

    public final StringPath md5hash = createString("md5hash");

    public final StringPath originalFileName = createString("originalFileName");

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QAssetFile(String variable) {
        this(AssetFile.class, forVariable(variable), INITS);
    }

    public QAssetFile(Path<? extends AssetFile> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QAssetFile(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QAssetFile(PathMetadata metadata, PathInits inits) {
        this(AssetFile.class, metadata, inits);
    }

    public QAssetFile(Class<? extends AssetFile> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

