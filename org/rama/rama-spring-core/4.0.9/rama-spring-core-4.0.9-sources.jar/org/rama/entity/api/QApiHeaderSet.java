package org.rama.entity.api;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QApiHeaderSet is a Querydsl query type for ApiHeaderSet
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QApiHeaderSet extends EntityPathBase<ApiHeaderSet> {

    private static final long serialVersionUID = -1971119719L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QApiHeaderSet apiHeaderSet = new QApiHeaderSet("apiHeaderSet");

    public final ListPath<java.util.Map<String, String>, SimplePath<java.util.Map<String, String>>> headers = this.<java.util.Map<String, String>, SimplePath<java.util.Map<String, String>>>createList("headers", java.util.Map.class, SimplePath.class, PathInits.DIRECT2);

    public final StringPath id = createString("id");

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QApiHeaderSet(String variable) {
        this(ApiHeaderSet.class, forVariable(variable), INITS);
    }

    public QApiHeaderSet(Path<? extends ApiHeaderSet> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QApiHeaderSet(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QApiHeaderSet(PathMetadata metadata, PathInits inits) {
        this(ApiHeaderSet.class, metadata, inits);
    }

    public QApiHeaderSet(Class<? extends ApiHeaderSet> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

