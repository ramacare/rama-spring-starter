package org.rama.entity.system;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QClientConfig is a Querydsl query type for ClientConfig
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QClientConfig extends EntityPathBase<ClientConfig> {

    private static final long serialVersionUID = 524152738L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QClientConfig clientConfig = new QClientConfig("clientConfig");

    public final StringPath computerName = createString("computerName");

    public final MapPath<String, Object, SimplePath<Object>> configuration = this.<String, Object, SimplePath<Object>>createMap("configuration", String.class, Object.class, SimplePath.class);

    public final StringPath fingerprint = createString("fingerprint");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final DateTimePath<java.time.OffsetDateTime> lastSeenDatetime = createDateTime("lastSeenDatetime", java.time.OffsetDateTime.class);

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QClientConfig(String variable) {
        this(ClientConfig.class, forVariable(variable), INITS);
    }

    public QClientConfig(Path<? extends ClientConfig> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QClientConfig(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QClientConfig(PathMetadata metadata, PathInits inits) {
        this(ClientConfig.class, metadata, inits);
    }

    public QClientConfig(Class<? extends ClientConfig> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

