package org.rama.entity.master;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QMasterId is a Querydsl query type for MasterId
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QMasterId extends EntityPathBase<MasterId> {

    private static final long serialVersionUID = -701864065L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QMasterId masterId = new QMasterId("masterId");

    public final NumberPath<Integer> id = createNumber("id", Integer.class);

    public final StringPath idType = createString("idType");

    public final StringPath prefix = createString("prefix");

    public final NumberPath<Integer> runningNumber = createNumber("runningNumber", Integer.class);

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QMasterId(String variable) {
        this(MasterId.class, forVariable(variable), INITS);
    }

    public QMasterId(Path<? extends MasterId> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QMasterId(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QMasterId(PathMetadata metadata, PathInits inits) {
        this(MasterId.class, metadata, inits);
    }

    public QMasterId(Class<? extends MasterId> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

