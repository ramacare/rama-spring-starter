package org.rama.entity.api;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QApi is a Querydsl query type for Api
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QApi extends EntityPathBase<Api> {

    private static final long serialVersionUID = 843180124L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QApi api = new QApi("api");

    public final QApiHeaderSet apiHeaderSet;

    public final StringPath apiHeaderSetId = createString("apiHeaderSetId");

    public final StringPath etlCode = createString("etlCode");

    public final StringPath etlCodeError = createString("etlCodeError");

    public final StringPath id = createString("id");

    public final StringPath sourceApiMethod = createString("sourceApiMethod");

    public final StringPath sourceApiUrl = createString("sourceApiUrl");

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QApi(String variable) {
        this(Api.class, forVariable(variable), INITS);
    }

    public QApi(Path<? extends Api> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QApi(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QApi(PathMetadata metadata, PathInits inits) {
        this(Api.class, metadata, inits);
    }

    public QApi(Class<? extends Api> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.apiHeaderSet = inits.isInitialized("apiHeaderSet") ? new QApiHeaderSet(forProperty("apiHeaderSet"), inits.get("apiHeaderSet")) : null;
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

