package org.rama.entity.system;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.dsl.StringTemplate;

import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.annotations.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QSystemParameter is a Querydsl query type for SystemParameter
 */
@SuppressWarnings("this-escape")
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QSystemParameter extends EntityPathBase<SystemParameter> {

    private static final long serialVersionUID = 1031331173L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QSystemParameter systemParameter = new QSystemParameter("systemParameter");

    public final StringPath parameterKey = createString("parameterKey");

    public final StringPath parameterValue = createString("parameterValue");

    public final org.rama.entity.QTimestampField timestampField;

    public final org.rama.entity.QUserstampField userstampField;

    public QSystemParameter(String variable) {
        this(SystemParameter.class, forVariable(variable), INITS);
    }

    public QSystemParameter(Path<? extends SystemParameter> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QSystemParameter(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QSystemParameter(PathMetadata metadata, PathInits inits) {
        this(SystemParameter.class, metadata, inits);
    }

    public QSystemParameter(Class<? extends SystemParameter> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.timestampField = inits.isInitialized("timestampField") ? new org.rama.entity.QTimestampField(forProperty("timestampField")) : null;
        this.userstampField = inits.isInitialized("userstampField") ? new org.rama.entity.QUserstampField(forProperty("userstampField")) : null;
    }

}

